import "../../../lib/vendor/codemirror/mode/yaml/yaml.js";
window.CodeMirror.__mode = "yaml";
export default window.CodeMirror;

import "../../../lib/vendor/codemirror/mode/sass/sass.js";
window.CodeMirror.__mode = "sass";
export default window.CodeMirror;

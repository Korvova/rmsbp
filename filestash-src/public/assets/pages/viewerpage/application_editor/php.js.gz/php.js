import "./clike.js";
import "../../../lib/vendor/codemirror/mode/php/php.js";
window.CodeMirror.__mode = "php";
export default window.CodeMirror;

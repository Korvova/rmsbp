import "../../../lib/vendor/codemirror/mode/css/css.js";
window.CodeMirror.__mode = "css";
export default window.CodeMirror;

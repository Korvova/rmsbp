import "../../../lib/vendor/codemirror/mode/clike/clike.js";
window.CodeMirror.__mode = "text/x-c++src";
export default window.CodeMirror;

import "../../../lib/vendor/codemirror/mode/diff/diff.js";
window.CodeMirror.__mode = "diff";
export default window.CodeMirror;

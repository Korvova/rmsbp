import "../../../lib/vendor/codemirror/mode/groovy/groovy.js";
window.CodeMirror.__mode = "text/x-groovy";
export default window.CodeMirror;

import "./clike.js";
window.CodeMirror.__mode = "text/x-java";
export default window.CodeMirror;

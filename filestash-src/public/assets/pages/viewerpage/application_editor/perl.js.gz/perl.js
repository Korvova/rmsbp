import "../../../lib/vendor/codemirror/mode/perl/perl.js";
window.CodeMirror.__mode = "perl";
export default window.CodeMirror;

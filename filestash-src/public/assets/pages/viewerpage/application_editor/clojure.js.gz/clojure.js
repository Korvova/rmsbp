import "../../../lib/vendor/codemirror/mode/clojure/clojure.js";
window.CodeMirror.__mode = "clojure";
export default window.CodeMirror;

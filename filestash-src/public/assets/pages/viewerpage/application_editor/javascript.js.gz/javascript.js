import "../../../lib/vendor/codemirror/mode/javascript/javascript.js";
window.CodeMirror.__mode = "javascript";
export default window.CodeMirror;

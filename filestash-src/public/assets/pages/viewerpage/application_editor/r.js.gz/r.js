import "../../../lib/vendor/codemirror/mode/r/r.js";
window.CodeMirror.__mode = "r";
export default window.CodeMirror;

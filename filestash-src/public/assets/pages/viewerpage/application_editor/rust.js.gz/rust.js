import "../../../lib/vendor/codemirror/mode/rust/rust.js";
window.CodeMirror.__mode = "rust";
export default window.CodeMirror;

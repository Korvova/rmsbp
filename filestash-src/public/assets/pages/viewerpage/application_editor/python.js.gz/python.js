import "../../../lib/vendor/codemirror/mode/python/python.js";
window.CodeMirror.__mode = "python";
export default window.CodeMirror;

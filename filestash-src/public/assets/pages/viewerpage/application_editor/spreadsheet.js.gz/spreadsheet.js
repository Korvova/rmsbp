import "../../../lib/vendor/codemirror/mode/spreadsheet/spreadsheet.js";
window.CodeMirror.__mode = "spreadsheet";
export default window.CodeMirror;

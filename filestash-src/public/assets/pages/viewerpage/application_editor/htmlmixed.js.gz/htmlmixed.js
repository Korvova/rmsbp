import "../../../lib/vendor/codemirror/mode/htmlmixed/htmlmixed.js";
window.CodeMirror.__mode = "htmlmixed";
export default window.CodeMirror;

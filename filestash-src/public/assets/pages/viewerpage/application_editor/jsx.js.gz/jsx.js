import "../../../lib/vendor/codemirror/mode/jsx/jsx.js";
window.CodeMirror.__mode = "jsx";
export default window.CodeMirror;

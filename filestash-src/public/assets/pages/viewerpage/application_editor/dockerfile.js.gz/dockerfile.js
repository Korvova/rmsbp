import "../../../lib/vendor/codemirror/mode/dockerfile/dockerfile.js";
window.CodeMirror.__mode = "dockerfile";
export default window.CodeMirror;

import "../../../lib/vendor/codemirror/mode/stex/stex.js";
window.CodeMirror.__mode = "stex";
export default window.CodeMirror;

import "../../../lib/vendor/codemirror/mode/properties/properties.js";
window.CodeMirror.__mode = "properties";
export default window.CodeMirror;

import "../../../lib/vendor/codemirror/mode/sql/sql.js";
window.CodeMirror.__mode = "sql";
export default window.CodeMirror;

import "../../../lib/vendor/codemirror/mode/ruby/ruby.js";
window.CodeMirror.__mode = "ruby";
export default window.CodeMirror;

import "../../../lib/vendor/codemirror/mode/gfm/gfm.js";
import "../../../lib/vendor/codemirror/mode/yaml-frontmatter/yaml-frontmatter.js";
window.CodeMirror.__mode = "yaml-frontmatter";
export default window.CodeMirror;

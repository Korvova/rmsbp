import "../../../lib/vendor/codemirror/mode/erlang/erlang.js";
window.CodeMirror.__mode = "erlang";
export default window.CodeMirror;

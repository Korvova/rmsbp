export default window.CodeMirror;

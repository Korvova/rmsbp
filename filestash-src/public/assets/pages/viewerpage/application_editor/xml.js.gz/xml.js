import "../../../lib/vendor/codemirror/mode/xml/xml.js";
window.CodeMirror.__mode = "xml";
export default window.CodeMirror;

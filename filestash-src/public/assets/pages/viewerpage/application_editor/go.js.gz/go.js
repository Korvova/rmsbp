import "../../../lib/vendor/codemirror/mode/go/go.js";
window.CodeMirror.__mode = "go";
export default window.CodeMirror;

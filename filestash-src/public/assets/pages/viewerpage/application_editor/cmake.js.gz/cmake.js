import "../../../lib/vendor/codemirror/mode/cmake/cmake.js";
window.CodeMirror.__mode = "cmake";
export default window.CodeMirror;

import "../../../lib/vendor/codemirror/mode/shell/shell.js";
window.CodeMirror.__mode = "shell";
export default window.CodeMirror;

import "../../../lib/vendor/codemirror/mode/sparql/sparql.js";
window.CodeMirror.__mode = "sparql";
export default window.CodeMirror;

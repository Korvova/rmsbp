import "../../../lib/vendor/codemirror/mode/lua/lua.js";
window.CodeMirror.__mode = "lua";
export default window.CodeMirror;

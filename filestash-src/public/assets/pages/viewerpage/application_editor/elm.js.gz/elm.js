import "../../../lib/vendor/codemirror/mode/elm/elm.js";
window.CodeMirror.__mode = "elm";
export default window.CodeMirror;

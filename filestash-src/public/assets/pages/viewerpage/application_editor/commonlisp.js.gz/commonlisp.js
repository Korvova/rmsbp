import "../../../lib/vendor/codemirror/mode/commonlisp/commonlisp.js";
window.CodeMirror.__mode = "commonlisp";
export default window.CodeMirror;
